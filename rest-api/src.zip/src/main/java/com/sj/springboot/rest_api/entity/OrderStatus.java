package com.sj.springboot.rest_api.entity;

public enum OrderStatus {
    PENDING, EXECUTED
}

